from django.contrib import admin
from irisjs.models import File

# Register your models here.

admin.site.register(File)
